using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;

namespace AudioConsumer.Controllers;

[ApiController]
[Route("[controller]")]
public class StreamController : ControllerBase
{
    private static Process? playProc;
    private static Process? saveProc;
    private const string ffplay = @"C:\playground\ffmpeg\ffplay.exe";
    private const string ffmpeg = @"C:\playground\ffmpeg\ffmpeg.exe";
    private const string producerPauseUrl = "https://localhost:7246/stream/pause";
    private const string producerResumeUrl = "https://localhost:7246/stream/resume";

    [HttpPost("startconsumer")]
    public async Task<IActionResult> StartConsumer()
    {
        Console.WriteLine("[Consumer] StartConsumer called");

        await CallProducer("start"); // ensure producer running

        StartProcesses();
        return Ok("consumer started");
    }

    [HttpPost("filter")]
    public async Task<IActionResult> ApplyFilter([FromBody] FilterReq req)
    {
        await CallProducer("pause");
        StopProcesses();

        var gain = req.Gain;
        var baseFreq = req.BasicFrequency;
        var widthHz = req.Width;

        var filterBuilder = new StringBuilder();
        double currentFreq = baseFreq;

        while (currentFreq <= 20000)
        {
            filterBuilder.AppendFormat("equalizer=f={0}:width_type=h:width={1}:g={2},", currentFreq, widthHz, gain);
            currentFreq += baseFreq;
        }

        // Remove trailing comma
        if (filterBuilder.Length > 0 && filterBuilder[^1] == ',')
            filterBuilder.Length--;

        string filterChain = filterBuilder.ToString();

        //var points = new List<string>();
        //for (int i = 1; baseFreq * i <= 20000; i++)
        //{
        //    int freq = baseFreq * i;
        //    points.Add($"entry({freq},{gain})");
        //}

        //string filter = $"firequalizer=gain_entry='{string.Join(";", points)}':multi=on";

        StartProcesses(filterChain);
        await CallProducer("resume");
        return Ok("harmonic filter applied");
    }


    [HttpPost("stopconsumer")]
    public IActionResult StopConsumer()
    {
        Console.WriteLine("[Consumer] StopConsumer called");
        StopProcesses();
        return Ok("consumer stopped");
    }

    private void StartProcesses(string audioFilter = null)
    {
        StopProcesses();

        string outPath = @$"C:\playground\media\recorded_{DateTime.Now:yyyyMMdd_HHmmss}.mp3";

        // Build ffmpeg args
        var ffmpegArgsBuilder = new StringBuilder();

        ffmpegArgsBuilder.Append($"-i tcp://127.0.0.1:9999 ");

        if (!string.IsNullOrWhiteSpace(audioFilter))
        {
            ffmpegArgsBuilder.Append($"-af \"{audioFilter}\" ");
        }

        //ffmpegArgsBuilder.Append("-map 0:a -f tee ");
        ffmpegArgsBuilder.Append("-c:a libmp3lame -map 0:a -f tee ");

        ffmpegArgsBuilder.Append($"\"[f=mp3]'{outPath}'|[f=mp3]pipe:1\"");

        saveProc = Process.Start(new ProcessStartInfo(ffmpeg, ffmpegArgsBuilder.ToString())
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        });

        // Pipe stdout from ffmpeg to ffplay (for real-time audio playback)
        playProc = Process.Start(new ProcessStartInfo(ffplay, "-nodisp -autoexit -f mp3 -")
        {
            RedirectStandardInput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        });

        // Connect ffmpeg output to ffplay input
        _ = Task.Run(async () =>
        {
            await saveProc.StandardOutput.BaseStream.CopyToAsync(playProc.StandardInput.BaseStream);
            playProc.StandardInput.Close();
        });

        saveProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Save ERR] " + e.Data); };
        saveProc.BeginErrorReadLine();

        playProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Play ERR] " + e.Data); };
        playProc.BeginErrorReadLine();
    }


    //private void StartProcesses(string audioFilter = null)
    //{
    //    StopProcesses();

    //    string playArgs = $"-nodisp -autoexit -f mp3";
    //    if (audioFilter != null) playArgs += $" -af \"{audioFilter}\"";
    //    playArgs += " tcp://127.0.0.1:9999";

    //    playProc = Process.Start(new ProcessStartInfo(ffplay, playArgs)
    //    {
    //        RedirectStandardError = true,
    //        UseShellExecute = false,
    //        CreateNoWindow = true
    //    });
    //    playProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Play ERR] " + e.Data); };
    //    playProc.BeginErrorReadLine();

    //    string outPath = @$"C:\playground\media\recorded_{DateTime.Now:yyyyMMdd_HHmmss}.mp3";
    //    string saveArgs = $"-f mp3";
    //    if (audioFilter != null) saveArgs += $" -af \"{audioFilter}\"";
    //    saveArgs += $" -i tcp://127.0.0.1:9999 \"{outPath}\"";

    //    saveProc = Process.Start(new ProcessStartInfo(ffmpeg, saveArgs)
    //    {
    //        RedirectStandardError = true,
    //        UseShellExecute = false,
    //        CreateNoWindow = true
    //    });
    //    saveProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Save ERR] " + e.Data); };
    //    saveProc.BeginErrorReadLine();
    //}

    private void StopProcesses()
    {

        try
        {
            if (playProc?.HasExited == false)
                playProc.Kill(true);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        try
        {
            if (saveProc?.HasExited == false)
                saveProc.Kill(true);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        playProc = null;
        saveProc = null;
    }

    private async Task CallProducer(string action)
    {
        using var client = new HttpClient();
        string url = $"https://localhost:7246/stream/{action}";
        Console.WriteLine($"[Consumer] Calling producer {action}");
        await client.PostAsync(url, null);
    }
}

public class FilterReq { public int BasicFrequency { get; set; } public int Width { get; set; } public int Gain { get; set; } }
