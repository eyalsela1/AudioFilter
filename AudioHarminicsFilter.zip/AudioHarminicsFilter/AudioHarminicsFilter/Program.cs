﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;

class Program
{
    static void Main()
    {
        string ffmpegPath = @"C:\playground\ffmpeg\ffmpeg.exe";
        string mediaDir = @"C:\playground\media";

        Console.Write("Enter the input audio filename (with extension): ");
        string inputFile = Console.ReadLine();

        string inputFilePath = Path.Combine(mediaDir, inputFile);
        if (!File.Exists(inputFilePath))
        {
            Console.WriteLine("Input file not found.");
            return;
        }

        Console.Write("Enter the basic frequency in Hz: ");
        if (!double.TryParse(Console.ReadLine(), out double baseFreq) || baseFreq <= 0)
        {
            Console.WriteLine("Invalid frequency.");
            return;
        }

        Console.Write("Enter the gain in dB (e.g. -60 to suppress): ");
        if (!double.TryParse(Console.ReadLine(), out double gain))
        {
            Console.WriteLine("Invalid gain.");
            return;
        }

        Console.Write("Enter the width in Hz : ");
        if (!double.TryParse(Console.ReadLine(), out double widthHz) || widthHz <= 0)
        {
            Console.WriteLine("Invalid width.");
            return;
        }

        string outputFileName = Path.GetFileNameWithoutExtension(inputFile) + "_output" + Path.GetExtension(inputFile);
        string outputFilePath = Path.Combine(mediaDir, outputFileName);

        // Build the filter chain using equalizer filters for each harmonic
        StringBuilder filterBuilder = new StringBuilder();
        double currentFreq = baseFreq;

        while (currentFreq <= 20000)
        {
            filterBuilder.AppendFormat("equalizer=f={0}:width_type=h:width={1}:g={2},", currentFreq, widthHz, gain);
            currentFreq += baseFreq;
        }

        // Remove the trailing comma
        if (filterBuilder.Length > 0)
            filterBuilder.Length--;

        string args = $"-y -i \"{inputFilePath}\" -af \"{filterBuilder}\" \"{outputFilePath}\"";

        Console.WriteLine("Running FFmpeg...");
        var ffmpeg = new Process
        {
            StartInfo = new ProcessStartInfo
            {
                FileName = ffmpegPath,
                Arguments = args,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            }
        };

        ffmpeg.Start();
        string stderr = ffmpeg.StandardError.ReadToEnd();
        ffmpeg.WaitForExit();

        if (ffmpeg.ExitCode == 0)
        {
            Console.WriteLine("Filtering complete.");
            Console.WriteLine("Output saved to: " + outputFilePath);
        }
        else
        {
            Console.WriteLine("FFmpeg encountered an error:");
            Console.WriteLine(stderr);
        }
    }
}