using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;

namespace AudioConsumer.Controllers;

[ApiController]
[Route("[controller]")]
public class StreamController : ControllerBase
{
    private static Process? playProc;
    private static Process? saveProc;
    private const string ffplay = @"C:\playground\ffmpeg\ffplay.exe";
    private const string ffmpeg = @"C:\playground\ffmpeg\ffmpeg.exe";
    private const string producerPauseUrl = "https://localhost:7246/stream/pause";
    private const string producerResumeUrl = "https://localhost:7246/stream/resume";
    private static List<string> createdFiles = new List<string>();

    [HttpPost("startconsumer")]
    public async Task<IActionResult> StartConsumer()
    {
        Console.WriteLine("[Consumer] StartConsumer called");

        await CallProducer("start"); // ensure producer running

        StartProcesses();
        return Ok("consumer started");
    }

    [HttpPost("restartfilter")]
    public async Task<IActionResult> RestartFilter()
    {
        Console.WriteLine("[Consumer] RestartFilter called");

        await CallProducer("pause"); // ensure producer running
        StopProcesses();
        StartProcesses();
        await CallProducer("resume");
        return Ok("harmonic filter reset");

    }


    [HttpPost("filter")]
    public async Task<IActionResult> ApplyFilter([FromBody] FilterReq req)
    {
        await CallProducer("pause");
        StopProcesses();

        var gain = req.Gain;
        var baseFreq = req.BasicFrequency;
        var widthHz = req.Width;

        var filterBuilder = new StringBuilder();
        double currentFreq = baseFreq;

        while (currentFreq <= 20000)
        {
            filterBuilder.AppendFormat("equalizer=f={0}:width_type=h:width={1}:g={2},", currentFreq, widthHz, gain);
            currentFreq += baseFreq;
        }

        // Remove trailing comma
        if (filterBuilder.Length > 0 && filterBuilder[^1] == ',')
            filterBuilder.Length--;

        string filterChain = filterBuilder.ToString();


        StartProcesses(filterChain);
        await CallProducer("resume");
        return Ok("harmonic filter applied");
    }


    [HttpPost("stopconsumer")]
    public IActionResult StopConsumer()
    {
        Console.WriteLine("[Consumer] StopConsumer called");
        StopProcesses();

        if (createdFiles.Count == 0)
            return Ok("No files to concatenate");

        string concatListPath = @"C:\playground\media\concat_list.txt";
        string outputFile = @"C:\playground\media\final_recording.mp3";

        try
        {
            using (var writer = new StreamWriter(concatListPath, false))
            {
                foreach (var file in createdFiles)
                {
                    writer.WriteLine($"file '{file.Replace("\\", "\\\\")}'");
                }
            }

            var ffmpegArgs = $"-f concat -safe 0 -i \"{concatListPath}\" -c copy \"{outputFile}\"";

            var concatProc = Process.Start(new ProcessStartInfo(ffmpeg, ffmpegArgs)
            {
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });

            concatProc.ErrorDataReceived += (s, e) => {
                if (!string.IsNullOrEmpty(e.Data))
                    Console.WriteLine("[Concat ERR] " + e.Data);
            };
            concatProc.BeginErrorReadLine();
            concatProc.WaitForExit();

            Console.WriteLine("[Consumer] Concatenation completed: " + outputFile);
        }
        catch (Exception ex)
        {
            Console.WriteLine("[Consumer ERR] Concatenation failed: " + ex.Message);
            return StatusCode(500, "Concatenation failed.");
        }
        finally
        {
            foreach (var file in createdFiles)
            {
                try
                {
                    if (System.IO.File.Exists(file))
                        System.IO.File.Delete(file);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Cleanup ERR] Could not delete {file}: {ex.Message}");
                }
            }
            try
            {
                if (System.IO.File.Exists(concatListPath))
                    System.IO.File.Delete(concatListPath);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[Cleanup ERR] Could not delete concat list: {ex.Message}");
            }

            createdFiles.Clear();
        }

        return Ok("Consumer stopped, files concatenated, and temporary files cleaned up.");
    }



    private void StartProcesses(string audioFilter = null)
    {
        StopProcesses();

        string outPath = @$"C:\playground\media\recorded_{DateTime.Now:yyyyMMdd_HHmmss}.mp3";
        createdFiles.Add(outPath);
        // Build ffmpeg args
        var ffmpegArgsBuilder = new StringBuilder();

        ffmpegArgsBuilder.Append($"-i tcp://127.0.0.1:9999 ");

        if (!string.IsNullOrWhiteSpace(audioFilter))
        {
            ffmpegArgsBuilder.Append($"-af \"{audioFilter}\" ");
        }

        //ffmpegArgsBuilder.Append("-map 0:a -f tee ");
        ffmpegArgsBuilder.Append("-c:a libmp3lame -map 0:a -f tee ");

        ffmpegArgsBuilder.Append($"\"[f=mp3]'{outPath}'|[f=mp3]pipe:1\"");

        saveProc = Process.Start(new ProcessStartInfo(ffmpeg, ffmpegArgsBuilder.ToString())
        {
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        });

        // Pipe stdout from ffmpeg to ffplay (for real-time audio playback)
        playProc = Process.Start(new ProcessStartInfo(ffplay, "-nodisp -autoexit -f mp3 -")
        {
            RedirectStandardInput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true
        });

        // Connect ffmpeg output to ffplay input
        _ = Task.Run(async () =>
        {
            await saveProc.StandardOutput.BaseStream.CopyToAsync(playProc.StandardInput.BaseStream);
            playProc.StandardInput.Close();
        });

        saveProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Save ERR] " + e.Data); };
        saveProc.BeginErrorReadLine();

        playProc.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Consumer Play ERR] " + e.Data); };
        playProc.BeginErrorReadLine();
    }
      
    private void StopProcesses()
    {

        try
        {
            if (playProc?.HasExited == false)
                playProc.Kill(true);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        try
        {
            if (saveProc?.HasExited == false)
                saveProc.Kill(true);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }
        playProc = null;
        saveProc = null;
    }

    private async Task CallProducer(string action)
    {
        using var client = new HttpClient();
        string url = $"https://localhost:7246/stream/{action}";
        Console.WriteLine($"[Consumer] Calling producer {action}");
        await client.PostAsync(url, null);
    }
}

public class FilterReq { public int BasicFrequency { get; set; } public int Width { get; set; } public int Gain { get; set; } }
