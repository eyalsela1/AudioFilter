using Microsoft.AspNetCore.Mvc;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;

namespace AudioProducer.Controllers;

[ApiController]
[Route("[controller]")]
public class StreamController : ControllerBase
{
    private static Process? ffmpegProcess;
    private static DateTime? streamStartTime;
    private static int pauseSecond = 0;
    private static readonly object lockObj = new();

    private const string filePath = @"C:\playground\media\cricketsandtalking.mp3";
    private const string ffmpeg = @"C:\playground\ffmpeg\ffmpeg.exe";
    private const string consumerUrl = "https://localhost:7114/stream/stopconsumer";

    [HttpPost("start")]
    public IActionResult StartStreaming()
    {
        lock (lockObj)
        {
            if (ffmpegProcess != null && !ffmpegProcess.HasExited)
                return BadRequest("Already streaming.");

            Console.WriteLine("[Producer] Starting from " + pauseSecond + "s");
            var args = $"-ss {pauseSecond} -re -i \"{filePath}\" -f mp3 -listen 1 tcp://0.0.0.0:9999";
            //var args = $"-re -i \"{filePath}\" -ss {pauseSecond} -f mp3 -listen 1 tcp://0.0.0.0:9999";
            ffmpegProcess = Process.Start(new ProcessStartInfo(ffmpeg, args)
            {
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            });
            ffmpegProcess.ErrorDataReceived += (s, e) => { if (!string.IsNullOrEmpty(e.Data)) Console.WriteLine("[Producer ERR] " + e.Data); };
            ffmpegProcess.BeginErrorReadLine();

            streamStartTime = DateTime.UtcNow;
        }
        return Ok("started");
    }

    [HttpPost("pause")]
    public IActionResult PauseStreaming()
    {
        lock (lockObj)
        {
            if (ffmpegProcess == null || ffmpegProcess.HasExited) return BadRequest("Not streaming");

            pauseSecond += (int)(DateTime.UtcNow - streamStartTime!.Value).TotalSeconds;
            Console.WriteLine("[Producer] Paused at " + pauseSecond + "s");

            ffmpegProcess.Kill();
            ffmpegProcess = null;
        }
        return Ok();
    }

    [HttpPost("resume")]
    public IActionResult ResumeStreaming()
    {
        Console.WriteLine("[Producer] Resume called");
        return StartStreaming();
    }

    [HttpPost("stop")]
    public async Task<IActionResult> StopStreaming()
    {
        lock (lockObj)
        {
            ffmpegProcess?.Kill();
            ffmpegProcess = null;
            pauseSecond = 0;
        }

        using var client = new HttpClient();
        try
        {
            Console.WriteLine("[Producer] Notifying consumer to stop");
            await client.PostAsync(consumerUrl, null);
        }
        catch (Exception ex)
        {
            Console.WriteLine("[Producer ERR] notify consumer: " + ex.Message);
        }

        return Ok("stopped");
    }
}
